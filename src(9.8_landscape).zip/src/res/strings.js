const strings = {
    splash: {
        title: 'Splash Screen',
    }
}

export default strings