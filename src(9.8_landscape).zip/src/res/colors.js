const colors = {
    title: '#00B75D',
    text: '#0C222B',
    button: '#036675'
}

export default colors