export default class FavoriteModel {
    title;
    url;

    constructor() {

    }

    setTitle(title) {
        this.title = title;
    }

    setUrl(url) {
        this.url = url;
    }
}