import { StyleSheet, Dimensions } from "react-native";

const win = Dimensions.get('window');

export default StyleSheet.create({
});
