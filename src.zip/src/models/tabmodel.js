export default class TabModel {
    title;
    url;
    image;

    constructor() {

    }

    setTitle(title) {
        this.title = title;
    }

    setUrl(url) {
        this.url = url;
    }

    setImage(image) {
        this.image = image;
    }
}